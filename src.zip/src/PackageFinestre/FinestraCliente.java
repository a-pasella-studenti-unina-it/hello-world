package PackageFinestre;
import PackageController.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;

public class FinestraCliente extends JFrame {

	private JPanel contentPane;
	public Controller IlController;
	public JTextField Nome_TF;
	public JTextField Cognome_TF;
	public JTextField DataNascita_TF;
	public JTextField TesseraFedelt�_TF;
	public JTextField ProdottoPreferito_TF;
	public JTextField CfTrovato_TF;

	/**
	 * Create the frame.
	 */
	public FinestraCliente(Controller c) {
		IlController=c;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 316);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Nome_JLb = new JLabel("Nome:");
		Nome_JLb.setBounds(10, 40, 62, 20);
		contentPane.add(Nome_JLb);
		
		JLabel Cognome_JLb = new JLabel("Cognome:");
		Cognome_JLb.setBounds(10, 80, 78, 20);
		contentPane.add(Cognome_JLb);
		
		JLabel DataNascita_JLb = new JLabel("Data di nascita:");
		DataNascita_JLb.setBounds(10, 120, 98, 20);
		contentPane.add(DataNascita_JLb);
		
		JLabel TesseraFedelt�_JLb = new JLabel("Numero tessera fedelt\u00E0:");
		TesseraFedelt�_JLb.setBounds(10, 160, 138, 20);
		contentPane.add(TesseraFedelt�_JLb);
		
		JLabel ProdottoPreferito_JLb = new JLabel("Tipo di prodotto preferito:");
		ProdottoPreferito_JLb.setBounds(10, 200, 153, 20);
		contentPane.add(ProdottoPreferito_JLb);
		
		Nome_TF = new JTextField();
		Nome_TF.setEditable(false);
		Nome_TF.setBounds(50, 41, 86, 18);
		contentPane.add(Nome_TF);
		Nome_TF.setColumns(10);
		
		Cognome_TF = new JTextField();
		Cognome_TF.setEditable(false);
		Cognome_TF.setBounds(75, 81, 86, 18);
		contentPane.add(Cognome_TF);
		Cognome_TF.setColumns(10);
		
		DataNascita_TF = new JTextField();
		DataNascita_TF.setEditable(false);
		DataNascita_TF.setBounds(100, 121, 86, 18);
		contentPane.add(DataNascita_TF);
		DataNascita_TF.setColumns(10);
		
		TesseraFedelt�_TF = new JTextField();
		TesseraFedelt�_TF.setEditable(false);
		TesseraFedelt�_TF.setBounds(150, 161, 86, 18);
		contentPane.add(TesseraFedelt�_TF);
		TesseraFedelt�_TF.setColumns(10);
		
		ProdottoPreferito_TF = new JTextField();
		ProdottoPreferito_TF.setEditable(false);
		ProdottoPreferito_TF.setBounds(155, 201, 86, 18);
		contentPane.add(ProdottoPreferito_TF);
		ProdottoPreferito_TF.setColumns(10);
		
		JButton DettagliTesseraButton = new JButton("Dettagli Tessera Fedelt\u00E0");
		DettagliTesseraButton.setBounds(243, 238, 181, 29);
		contentPane.add(DettagliTesseraButton);
		
		CfTrovato_TF = new JTextField();
		CfTrovato_TF.setFont(new Font("Tahoma", Font.BOLD, 12));
		CfTrovato_TF.setEditable(false);
		CfTrovato_TF.setBounds(170, 4, 170, 18);
		contentPane.add(CfTrovato_TF);
		CfTrovato_TF.setColumns(10);
		
		JLabel Cf_JLb = new JLabel("Codice Fiscale:");
		Cf_JLb.setFont(new Font("Trebuchet MS", Font.BOLD, 12));
		Cf_JLb.setBounds(78, 4, 113, 18);
		contentPane.add(Cf_JLb);
	}
}
