package PackageEntit�;
import java.util.*;

public class Farinacei extends Prodotto{

	@Override
	public void CalcolaPrezzo() {
		// TODO Auto-generated method stub
		super.CalcolaPrezzo();
	}
	
	public Farinacei() {
		// TODO Auto-generated constructor stub
	}

}
