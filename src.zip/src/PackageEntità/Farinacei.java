package PackageEntit�;
import java.util.*;

public class Farinacei extends Prodotto{
	
	private Date DataDiRaccolta;
	
	public Date getDataDiRaccolta() {
		return DataDiRaccolta;
	}
	public void setDataDiRaccolta(Date dataDiRaccolta) {
		DataDiRaccolta = dataDiRaccolta;
	}

	@Override
	public void CalcolaPrezzo() {
		// TODO Auto-generated method stub
		super.CalcolaPrezzo();
	}
	
	public Farinacei() {
		// TODO Auto-generated constructor stub
	}

}
