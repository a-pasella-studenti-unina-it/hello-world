package PackageEntit�;
import java.util.*;

public class Carrello {
	
	private double PrezzoTotale;
	public Cliente Acquirente;
	
	public LinkedList<Prodotto> ProdottiInCarrello = new LinkedList<Prodotto>();

	

	public double getPrezzoTotale() {
		return PrezzoTotale;
	}
	public void setPrezzoTotale(double prezzoTotale) {
		PrezzoTotale = prezzoTotale;
	}

	public void AggiungiAlCarrello(Prodotto prodotto) {
		
		
	}

	public Carrello() {
		// TODO Auto-generated constructor stub
	}

}
