package PackageEntit�;
import java.util.*;

import PackageController.Controller;

public class Prodotto {
	
	private String NomeProdotto;
	private String tipo;
	private int Disponibilit�;
	private String Marca;
	private String CodiceID;
	private double PrezzoAlKilo;
	private double Quantit�;
	private Date DataDiScadenza;
	private Date DataDiRaccolta;
	private String Modalit�DiConservazione;
	private Date DataConfezionamento;
	private Date DataDiProduzione;
	private String PaeseDiCondizionamento;
	private Date DataDiDeposizione;
	public Carrello IlCarrello = new Carrello();
	
	public Date getDataDiRaccolta() {
		return DataDiRaccolta;
	}
	public void setDataDiRaccolta(Date dataDiRaccolta) {
		DataDiRaccolta = dataDiRaccolta;
	}
	public String getModalit�DiConservazione() {
		return Modalit�DiConservazione;
	}
	public void setModalit�DiConservazione(String modalit�DiConservazione) {
		Modalit�DiConservazione = modalit�DiConservazione;
	}

	//public ArrayList<Carrello> IlCarrello= new ArrayList<Carrello>();
	
	

	public int getDisponibilit�() {
		return Disponibilit�;
	}
	public void setDisponibilit�(int disponibilit�) {
		Disponibilit� = disponibilit�;
	}
	public String getMarca() {
		return Marca;
	}
	public void setMarca(String marca) {
		Marca = marca;
	}
	public String getCodiceID() {
		return CodiceID;
	}
	public void setCodiceID(String codiceID) {
		CodiceID = codiceID;
	}
	public double getPrezzoAlKilo() {
		return PrezzoAlKilo;
	}
	public void setPrezzoAlKilo(double prezzoAlKilo) {
		PrezzoAlKilo = prezzoAlKilo;
	}
	public double getQuantit�() {
		return Quantit�;
	}
	public void setQuantit�(double quantit�) {
		Quantit� = quantit�;
	}
	
	public String getNomeProdotto() {
		return NomeProdotto;
	}
	public void setNomeProdotto(String nomeProdotto) {
		NomeProdotto = nomeProdotto;
	}
	public Date getDataDiScadenza() {
		return DataDiScadenza;
	}
	public void setDataDiScadenza(Date dataDiScadenza) {
		DataDiScadenza = dataDiScadenza;
	}
	
	public void CalcolaPrezzo(){
	}
	
	public Prodotto() {	
	}
	
	public Date getDataConfezionamento() {
		return DataConfezionamento;
	}
	public void setDataConfezionamento(Date dataConfezionamento) {
		DataConfezionamento = dataConfezionamento;
	}
	public Date getDataDiProduzione() {
		return DataDiProduzione;
	}
	public void setDataDiProduzione(Date dataDiProduzione) {
		DataDiProduzione = dataDiProduzione;
	}
	public String getPaeseDiCondizionamento() {
		return PaeseDiCondizionamento;
	}
	public void setPaeseDiCondizionamento(String paeseDiCondizionamento) {
		PaeseDiCondizionamento = paeseDiCondizionamento;
	}
	public Date getDataDiDeposizione() {
		return DataDiDeposizione;
	}
	public void setDataDiDeposizione(Date dataDiDeposizione) {
		DataDiDeposizione = dataDiDeposizione;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	

}
