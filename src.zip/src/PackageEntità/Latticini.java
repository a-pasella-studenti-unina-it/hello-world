package PackageEntit�;
import java.util.*;

public class Latticini extends Prodotto{

	private Date DataDiProduzione;
	private String PaeseDiCondizionamento;
	
	@Override
	public Date getDataDiProduzione() {
		return DataDiProduzione;
	}
	@Override
	public void setDataDiProduzione(Date dataDiProduzione) {
		DataDiProduzione = dataDiProduzione;
	}
	@Override
	public String getPaeseDiCondizionamento() {
		return PaeseDiCondizionamento;
	}
	@Override
	public void setPaeseDiCondizionamento(String paeseDiCondizionamento) {
		PaeseDiCondizionamento = paeseDiCondizionamento;
	}

	@Override
	public void CalcolaPrezzo() {
		// TODO Auto-generated method stub
		super.CalcolaPrezzo();
	}
	
	public Latticini() {
		// TODO Auto-generated constructor stub
	}

}
