package PackageDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CarrelloDAO {
	
	public void ScalaDisp(Double quantita, String nome_prodotto) {
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch(ClassNotFoundException e) {
			System.out.println("Class not found:\n"+e);
		}
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/progetto", "postgres", "basididati");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("UPDATE prodotto SET disponibilita = disponibilita - "+quantita+" WHERE prodotto.nome_prodotto = '"+nome_prodotto+"'");
			
			
			rs.close();
			st.close();
			conn.close();
			
		} catch(SQLException e) {		
		}
		
	}
	
}


